/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consulta;

/**
 *
 * @author HP
 */



public class Participante {
//Clase Participante para representar a un participante en un evento.
    String nombre;
    int edad;
    String equipo;

    public Participante(String nombre, int edad, String equipo) {
        this.nombre = nombre;
        this.edad = edad;
        this.equipo = equipo;
    }
}


