/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consulta;

/**
 *
 * @author HP
 */


public class ListaParticipantes {
//Clase ListaParticipantes para manejar la lista de participantes de un evento
    Participante[] participantes;
    int size;

    public ListaParticipantes() {
        this.participantes = new Participante[10]; // Tamaño inicial arbitrario
        this.size = 0;
    }

    public void agregarParticipante(Participante participante) {
        if (size < participantes.length) {
            participantes[size++] = participante;
        } else {
            // Manejar crecimiento dinámico del arreglo si se llena
            // Código simplificado para demostración
            System.out.println("No se pueden agregar más participantes.");
        }
    }

    public void mostrarListaParticipantes() {
        for (int i = 0; i < size; i++) {
            System.out.println(participantes[i].nombre + " - " + participantes[i].equipo);
        }
    }

    public Participante buscarParticipante(String nombre) {
        for (int i = 0; i < size; i++) {
            if (participantes[i].nombre.equals(nombre)) {
                return participantes[i];
            }
        }
        return null;
    }
}


