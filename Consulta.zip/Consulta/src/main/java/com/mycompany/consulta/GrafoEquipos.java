/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consulta;
import java.util.LinkedList;
/**
 *
 * @author HP
 */

/**
 *
 * Clase GrafoEquipos para representar el grafo de relaciones entre equipos
 */
public class GrafoEquipos {
//Clase GrafoEquipos para representar el grafo de relaciones entre equipos
 
    LinkedList<Equipo> equipos; // Usamos LinkedList en lugar de ArrayList

    public GrafoEquipos() {
        this.equipos = new LinkedList<>(); // Inicializamos como LinkedList
    }

    public void agregarEquipo(String nombreEquipo) {
        equipos.add(new Equipo(nombreEquipo));
    }

    public void agregarPartido(String nombreEquipo1, String nombreEquipo2) {
        Equipo equipo1 = buscarEquipo(nombreEquipo1);
        Equipo equipo2 = buscarEquipo(nombreEquipo2);
        if (equipo1 != null && equipo2 != null) {
            equipo1.agregarRival(equipo2);
            equipo2.agregarRival(equipo1);
        }
    }

    public Equipo buscarEquipo(String nombre) {
        for (Equipo equipo : equipos) {
            if (equipo.nombre.equals(nombre)) {
                return equipo;
            }
        }
        return null;
    }

    public LinkedList<Equipo> obtenerRivales(String nombreEquipo) {
        Equipo equipo = buscarEquipo(nombreEquipo);
        if (equipo != null) {
            return equipo.obtenerRivales();
        }
        return null;
    }
}

