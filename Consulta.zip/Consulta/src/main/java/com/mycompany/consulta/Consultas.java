/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consulta;

import java.util.LinkedList;

/**
 *
 * @author HP
 */


/**
 *
 * Clase principal para ejecutar consultas y ejemplos del sistema.
 */
public class Consultas {

    public static void main(String[] args) {

        // Crear lista de participantes para un evento de fútbol
        ListaParticipantes listaFutbol = new ListaParticipantes();
        listaFutbol.agregarParticipante(new Participante("Juan Pérez", 25, "Equipo A"));
        listaFutbol.agregarParticipante(new Participante("María Gómez", 27, "Equipo B"));

        // Mostrar la lista de participantes
        System.out.println("Lista de participantes del evento de fútbol:");
        listaFutbol.mostrarListaParticipantes();

        // Buscar un participante por nombre
        String nombreABuscar = "Juan Pérez";
        Participante participanteEncontrado = listaFutbol.buscarParticipante(nombreABuscar);
        if (participanteEncontrado != null) {
            System.out.println("Participante encontrado: " + participanteEncontrado.nombre);
        } else {
            System.out.println("Participante no encontrado.");
        }

        // Crear grafo de equipos y agregar algunos equipos y partidos
        GrafoEquipos grafoEquipos = new GrafoEquipos();
        grafoEquipos.agregarEquipo("Equipo A");
        grafoEquipos.agregarEquipo("Equipo B");
        grafoEquipos.agregarEquipo("Equipo C");

        // Establecer relaciones (partidos jugados) entre equipos
        grafoEquipos.agregarPartido("Equipo A", "Equipo B");
        grafoEquipos.agregarPartido("Equipo A", "Equipo C");
        grafoEquipos.agregarPartido("Equipo B", "Equipo C");

        // Consultar rivales de un equipo
        System.out.println("Rivales del Equipo A:");
        LinkedList<Equipo> rivalesEquipoA = grafoEquipos.obtenerRivales("Equipo A");
        if (rivalesEquipoA != null) {
            for (Equipo rival : rivalesEquipoA) {
                System.out.println("- " + rival.nombre);
            }
        } else {
            System.out.println("Equipo no encontrado.");
        }
    }
}

     
        
        


    


   